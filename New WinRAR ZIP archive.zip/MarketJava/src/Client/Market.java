package Client;

public class Market {
}
